# Music-Online-Website-
Developed a music online website similar to spotify through which you can interact and build social networking with fans and bands.
I have used HTML5 ,CSS3  , javascript, Jquery ,PHP and MYSQL database to develop the webpage.
The above site requires a Server to run.


Contact me if you are facing any issues.
amitk26467@gmail.com
